<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
    'chunks' => 
    array (
    ),
    'setup-options' => 'dasite-1.0.1-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fc5aede301e059b464ce194054641738',
      'native_key' => 'dasite',
      'filename' => 'modNamespace/65ec64813604acd12d635d54b59b35bd.vehicle',
      'namespace' => 'dasite',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4d5b026a3b6eb25c866d3e68c6415688',
      'native_key' => NULL,
      'filename' => 'modCategory/c22f52b38a6c196e9bcd200fea122c22.vehicle',
      'namespace' => 'dasite',
    ),
  ),
);